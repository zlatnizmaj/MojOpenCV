# MiAI_OpenCV_Sample
A simple sample of OpenCV with Python

#MìAI <br>
Fanpage: http://facebook.com/miaiblog <br>
Group trao đổi, chia sẻ: https://facebook.com/groups/miaigroup <br>
Blog: https://miai.vn<br>
Youtube: http://bit.ly/miai_youtube  
