# OpenCV Python Tutorials

Tổng hợp code được sử dụng trong các bài hướng dẫn về OpenCV từ blog [EzCodin](http://ezcodin.com/opencv).

Cài đặt thư viện:

```bash
pip install numpy==1.18.1 opencv-python==4.1.0.25 matplotlib==3.1.3
```

